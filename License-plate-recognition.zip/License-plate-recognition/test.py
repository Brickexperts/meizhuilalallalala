# -*- coding: utf-8 -*-
import json

def getCarInformation():
    global count
    count = 0
    with open('E:/test/test.json', 'r',encoding='utf-8') as f:
        files = f.readlines()
        list1 = []
        for i in files:
            user_dict = json.loads(i)
            list1.append(user_dict)
        return list1


def CarID_to_Information():
    data = getCarInformation()
    for i in data:
        print(i)
    count = len(data)
    for i in range(count):
        print(data[i]["carid"])



if __name__=="__main__":
    CarID_to_Information()