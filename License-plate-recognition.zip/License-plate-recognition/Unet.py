# -*- coding:utf-8 -*-
import numpy as np
import os
import cv2
from tensorflow.keras import layers, losses, models
#读取训练数据
def unet_train():
#注意：一定不要改这里的长宽，unet不支持任意大小的图像。可以将图片resize一下
    height = 512
    width = 512
    path = 'E:/CarIdentity train/full_dataset/'
    input_name = os.listdir(path + 'train_image')
    #n = len(input_name)
    n=400
    print(n)
    X_train, y_train = [], []
    for i in range(n):
        print("正在读取第%d张图片" % i)
        img = cv2.imread(path + 'train_image/%d.png' % i)
        img=cv2.resize(img,(512,512))
        label = cv2.imread(path + 'train_label/%d.png' % i)
        label=cv2.resize(label,(512,512))
        X_train.append(img)
        y_train.append(label)
        #(400,512,512,3)
    X_train = np.array(X_train)
    y_train = np.array(y_train)

    def Conv2d_BN(x, nb_filter, kernel_size, strides=(1, 1), padding='same'):
        #二维卷积
        x = layers.Conv2D(nb_filter, kernel_size, strides=strides, padding=padding)(x)
        #批量归一化
        x = layers.BatchNormalization(axis=3)(x)
        #激活函数
        x = layers.LeakyReLU(alpha=0.1)(x)
        return x

    def Conv2dT_BN(x, filters, kernel_size, strides=(2, 2), padding='same'):
        #反卷积
        x = layers.Conv2DTranspose(filters, kernel_size, strides=strides, padding=padding)(x)
        x = layers.BatchNormalization(axis=3)(x)
        x = layers.LeakyReLU(alpha=0.1)(x)
        return x

    inpt = layers.Input(shape=(height, width, 3))
    conv1 = Conv2d_BN(inpt, 8, (3, 3))

    conv1 = Conv2d_BN(conv1, 8, (3, 3))

    #最大值池化
    pool1 = layers.MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same')(conv1)

    conv2 = Conv2d_BN(pool1, 16, (3, 3))
    conv2 = Conv2d_BN(conv2, 16, (3, 3))
    pool2 = layers.MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same')(conv2)

    conv3 = Conv2d_BN(pool2, 32, (3, 3))
    conv3 = Conv2d_BN(conv3, 32, (3, 3))

    pool3 = layers.MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same')(conv3)

    conv4 = Conv2d_BN(pool3, 64, (3, 3))
    conv4 = Conv2d_BN(conv4, 64, (3, 3))
    pool4 = layers.MaxPooling2D(pool_size=(2, 2), strides=(2, 2), padding='same')(conv4)

    conv5 = Conv2d_BN(pool4, 128, (3, 3))
    #dropout防止过拟合
    conv5 = layers.Dropout(0.5)(conv5)
    conv5 = Conv2d_BN(conv5, 128, (3, 3))
    conv5 = layers.Dropout(0.5)(conv5)
    convt1 = Conv2dT_BN(conv5, 64, (3, 3))

    #print(convt1)
    #print(conv4)

    concat1 = layers.concatenate([conv4, convt1], axis=3)
    #print(concat1)
    concat1 = layers.Dropout(0.5)(concat1)
    conv6 = Conv2d_BN(concat1, 64, (3, 3))
    conv6 = Conv2d_BN(conv6, 64, (3, 3))
    convt2 = Conv2dT_BN(conv6, 32, (3, 3))
    concat2 = layers.concatenate([conv3, convt2], axis=3)
    concat2 = layers.Dropout(0.5)(concat2)
    conv7 = Conv2d_BN(concat2, 32, (3, 3))
    conv7 = Conv2d_BN(conv7, 32, (3, 3))

    convt3 = Conv2dT_BN(conv7, 16, (3, 3))
    concat3 = layers.concatenate([conv2, convt3], axis=3)
    concat3 = layers.Dropout(0.5)(concat3)
    conv8 = Conv2d_BN(concat3, 16, (3, 3))
    conv8 = Conv2d_BN(conv8, 16, (3, 3))

    convt4 = Conv2dT_BN(conv8, 8, (3, 3))
    concat4 = layers.concatenate([conv1, convt4], axis=3)
    #print(conv1)
    #print(convt4)
    #assert 1>2
    concat4 = layers.Dropout(0.5)(concat4)
    conv9 = Conv2d_BN(concat4, 8, (3, 3))
    conv9 = Conv2d_BN(conv9, 8, (3, 3))
    conv9 = layers.Dropout(0.5)(conv9)

    outpt = layers.Conv2D(filters=3, kernel_size=(1, 1), strides=(1, 1), padding='same', activation='relu')(conv9)

    #keras通过两个API提供两种计算模型 1、通过Model类API  2、通过Sequential类API
    model = models.Model(inpt, outpt)
    #训练参数
    model.compile(optimizer='adam',#指定优化器
                  loss='mean_squared_error',#指定损失函数
                  metrics=['accuracy'])
    #输出模型各层的参数情况
    #model.summary()
    """print("开始训练u-net")
    print("conv1",conv1)
    print("convt1",convt1)
    print("conv2",conv2)
    print("convt2",convt2)
    print("conv3",conv3)
    print("convt3",convt3)
    print("conv4",conv4)
    print("convt4",convt4)
    print("conv5",conv5)
    print("conv6",conv6)
    print("conv7", conv7)
    print("conv8", conv8)
    print("conv9", conv9)
    print("inpt shape",inpt.shape)
    print("outpt shape",outpt.shape)
    print("X_train",X_train.shape)
    print("y_train",y_train.shape)"""
    #assert 1>2
    model.fit(X_train, y_train, epochs=30, batch_size=3)#epochs和batch_size看个人情况调整，batch_size不要过大，否则内存容易溢出
    model.save('unet.h5')
    print('unet.h5保存成功!!!')


def unet_predict(unet, img_src_path):
    #img_src = cv2.imdecode(np.fromfile(img_src_path, dtype=np.float32), -1)  # 从中文路径读取时用
    img_src=cv2.imread(img_src_path)
    if img_src.shape != (512, 512, 3):
        #将图片resize成 512 x 512
        img_src = cv2.resize(img_src, dsize=(512, 512), interpolation=cv2.INTER_AREA)[:, :, :3]  # dsize=(宽度,高度),[:,:,:3]是防止图片为4通道图片，后续无法reshape
    img_src = img_src.reshape(1, 512, 512, 3)  # 预测图片shape为(1,512,512,3)

    img_mask = unet.predict(img_src)  # 归一化除以255后进行预测
    img_src = img_src.reshape(512, 512, 3)  # 将原图reshape为3维
    img_mask = img_mask.reshape(512, 512, 3)  # 将预测后图片reshape为3维
    img_mask = img_mask / np.max(img_mask) * 255  # 归一化后乘以255
    img_mask[:, :, 2] = img_mask[:, :, 1] = img_mask[:, :, 0]  # 三个通道保持相同
    img_mask = img_mask.astype(np.uint8)  # 将img_mask类型转为int型

    return img_src, img_mask
