# -*- coding:utf-8 -*-
import cv2

from tensorflow import keras
from core import locate_and_correct
from Unet import unet_predict
from CNN import cnn_predict
import time
from read_information import *
def Start(path):

#   E:/CarIdentity train/full_dataset/full_image/0.jpg
    unet = keras.models.load_model('unet.h5')
    cnn = keras.models.load_model('cnn.h5')
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    img = cv2.resize(img, (512, 512))
    #cv2.imshow("test",img)
    print('正在启动中,请稍等...')
    #time.sleep(3)
    print("已启动,开始识别吧！")
    #img = cv2.imdecode(np.fromfile(path, dtype=np.uint8), -1)  # 从中文路径读取时用
    h, w = img.shape[0], img.shape[1]

    if h * w <= 240 * 80 and 2 <= w / h <= 5:  # 满足该条件说明可能整个图片就是一张车牌,无需定位,直接识别即可
        lic = cv2.resize(img, dsize=(240, 80), interpolation=cv2.INTER_AREA)[:, :, :3]  # 直接resize为(240,80)
        img_src_copy, Lic_img = img, [lic]
    else:  # 否则就需通过unet对img_src原图预测,得到img_mask,实现车牌定位,然后进行识别
        img_src, img_mask = unet_predict(unet, path)
        img_src_copy, Lic_img = locate_and_correct(img_src, img_mask)  # 利用core.py中的locate_and_correct函数进行车牌定位和矫正

    Lic_pred = cnn_predict(cnn, Lic_img)
    if Lic_pred:
        #print(type(Lic_pred[0][1]))
        return Lic_pred[0][1]
    else:  # Lic_pred为空说明未能识别
        return 0



"""if __name__ == '__main__':

    carID=Start("E:/CarIdentity train/License-plate-recognition/upload/2.jpg")
    CarID_to_Information(carID)
    owner_name, owner_telephone = CarID_to_Information(carID)
    print(owner_name,owner_telephone)"""