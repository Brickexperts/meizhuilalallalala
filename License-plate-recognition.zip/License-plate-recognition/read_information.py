# -*- coding: utf-8 -*-
import json
def addCarInformation():
  informationlist=getCarInformation()
  sum1=len(informationlist)
  list1=[]
  for i in range(sum1):
    #print(informationlist[i])
    #print(informationlist[i]["carid"])
    list1.append(informationlist[i]["carid"])
  #print(list1)
  n=int(input("你要添加几个人的信息："))
  for i in range(n):
    carID=input("请输入车牌号：")
    if carID in list1:
        print("该车牌号已存在,请输入下一位车的信息")
        continue
    carOwner=input("请输入车主名字：")
    carOwnerTel=input("请输入车主电话：")
    print("*"*50)
    dict_1={'carid':carID,'name':carOwner,'telephone':carOwnerTel}
    with open('E:/test/test.json', 'a+') as f:
      f.write(json.dumps(dict_1)+'\n')
  print("finish")

def getCarInformation():
  global count
  count=0
  with open('E:/test/test.json', 'r',encoding="utf-8") as f:
      """print(json.loads(f.readline()))
      print(json.loads(f.readline()))
      print(json.loads(f.readline()))"""
      files=f.readlines()
      #print(files)
      information_list=[]
      plate_list=[]
      for i in files:
        user_dict=json.loads(i)
        information_list.append(user_dict)
        #print(user_dict)
        plate_list.append(user_dict["carid"])
      #print(list1)
      return information_list,plate_list

def CarID_to_Information(carid):
  information_list,plate_list=getCarInformation()
  #print(type(data[3]))
  #print(count)
  #print(data[2]["carid"])
  #assert 1>2
  count=len(information_list)
  #print(count)
  """for i in range(count):
    print(data[i]["carid"])]"""
  for i in range(count):
    if carid in plate_list:
        return information_list[i]["name"],information_list[i]["telephone"]
    else:
        return 0,0
  
"""if __name__=="__main__":
    information_list,plate_list=getCarInformation()
    print(information_list)
    print(plate_list)

    
    #记录json的个数
  
  #addCarInformation()
  #getCarInformation()
carid=input("请输入你需要找的车牌：")
  owner_name,owner_telephone=CarID_to_Information(carid)
  print(type(owner_name))
  print(type(owner_telephone))
  assert 1>2
  print(owner_name,owner_telephone)"""